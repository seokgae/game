function br(){
    document.write("<br>");
}

function hr(){
    document.write("<hr>");
}

function RandomizeAttack(value) {
    return Math.floor(Math.random()*value+1);
}

function Battle_start() {
    hr();document.write("전투시작");hr();
}
